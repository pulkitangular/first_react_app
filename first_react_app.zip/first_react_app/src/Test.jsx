import { useState } from "react"; 
const Test=()=>{
    return(
    <>
    <h1>Test</h1>
    <p>
        Test text for goes here.
    </p>
    </>
    )

}

export default Test;